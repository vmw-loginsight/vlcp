if(Test-Path clrevents.csv)
{
	Remove-Item clrevents.csv;
}
if(Test-Path clrevents.etl)
{
	Remove-Item clrevents.etl;
}
xperf -start clr -on e13c0d23-ccbc-4e12-931b-d9cc2eee27e4:0x1CCBD:5 -f clrevents.etl
Start-Sleep -s 240
Xperf -stop clr
xperf -i clrevents.etl -o clrevents.csv
