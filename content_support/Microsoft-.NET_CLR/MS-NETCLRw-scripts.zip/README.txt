1. Compatibility:
------------------
.Net CLR (Framework 4.5, 4)

2. Installation:
------------------
Navigate to the "Content Pack" menu in Log Insight.  Select the "Import Content Pack" button.  In the "Import Content Pack" menu, do the following:
-	Select the "Browse..." button and select the content pack you are trying to import
-	Select the "Install as content pack" radio button
-	Select the "Import" button

Alternately, you can also install the content pack from the marketplace available on Log Insight UI
-On Log Insight UI, browse to Content Pack ->Marketplace 
-Click on the content pack and then click �Install�


3. Configuration:
------------------
3.1  Script - ms_clr_event_logging.ps1
----------------------------------------

Copy the scripts directory from the root of the archive downloaded from Solution Exchange to a permanent location. For example: C:\ProgramData\VMware\Log Insight Agent\dotNetClr\. Create a task in Windows Task Scheduler to execute the PowerShell scripts bundled in the scripts directory with the following configurations:

-	Run as user with sufficient permissions
-	Browse to Control Panel --> All Control Panel Items --> Administrative Tools --> Task Scheduler and click on create task.
-	Set to: Run whether user is logged on or not
-	Set to: Run with highest privileges
-	Action is set to: Start a program
  - Program: C:\ProgramData\VMware\Log Insight Agent\dotNetClr\scripts\open_powershell.cmd
  - Add arguments/Parameters: ms_clr_event_logging.ps1
  - Start in: C:\ProgramData\VMware\Log Insight Agent\dotNetClr\scripts\
  -	Trigger is set to Daily
  - Repeat task every 5 minutes for the duration of 1 day
  
Note: The duration of the task can be set as per the actual environment.


3.2 liagent.ini configuration:
--------------------------------

3.2.1  Using Agent Group:
-------------------------

The  "Microsoft - .NET CLR"  content pack requires the use of the Log Insight agent with the cfapi protocol (default) and the included agent group configuration. To apply the agent group configuration:

* Go to the  Administration -> Management -> Agents page (requires Super Admin privileges)
* Select the  All Agents  drop-down at the top of the window and select the  �Copy Template�  button to the right of the "Microsoft - .NET CLR" agent group
* Add the desired filters to restrict which agent receive the configuration (optional)
* Select the "Refresh" button at the top of the page
* Select the "Save Configuration" button at the bottom of the page